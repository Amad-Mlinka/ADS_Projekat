$(document).ready(() => {
    console.log("circle-follow js ucitan");
    $(document).mousemove((e) => {
        $(".pointer").css({ left: e.pageX - 10, top: e.pageY - 9 })
    })
});