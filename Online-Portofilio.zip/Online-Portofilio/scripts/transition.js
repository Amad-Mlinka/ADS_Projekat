$(document).ready(() => {
    console.log("transition js ucitan");
    localStorage.getItem('mode') === 'dark-theme' ? document.querySelector('body').classList.add('dark-theme') && document.querySelector('body').classList.remove('light-theme') : document.querySelector('body').classList.add('light-theme') && document.querySelector('body').classList.remove('dark-theme')
    console.log(localStorage);
});

$(document).on('click', '.trigger', () => {
    event.stopPropagation();
    event.stopImmediatePropagation();
    localStorage.setItem('mode', (localStorage.getItem('mode') || 'dark-theme') === 'dark-theme' ? 'light-theme' : 'dark-theme');
    if (localStorage.getItem('mode') === 'dark-theme') {
        if (document.querySelector('body').classList.contains('light-theme')) {
            document.querySelector('body').classList.remove('light-theme');
        }
        document.querySelector('body').classList.add('dark-theme');
    } else {
        if (document.querySelector('body').classList.contains('dark-theme')) {
            document.querySelector('body').classList.remove('dark-theme');
        }
        document.querySelector('body').classList.add('light-theme');
    };
    console.log(localStorage);
    console.log("Promijena teme");

});